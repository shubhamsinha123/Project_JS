
  $(document).ready(function(){ 
    $('.contact_name').on('input', function() {
      console.log("name");
        var input=$(this);
        var is_name=input.val();
        console.log(is_name);
        if(is_name != ''){
            input.removeClass("invalid").addClass("valid");
        }
        else{
            input.removeClass("valid").addClass("invalid");
        }
    });
    $('.contact_name').focusout(function(){
      if($('.contact_name').hasClass("invalid")){
        $('.contact_name').after('<br><span class="error">This field must not be empty</span>');
      }
      else{
        $(".error").remove();
      }
    });
    // Email must be an email
    $('.contact_email').on('input', function() {
        var input=$(this);
        var re = /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
        var is_email=re.test(input.val());
        if(is_email){
            input.removeClass("invalid").removeClass("error").addClass("valid");
        }
        else{
            input.removeClass("valid").addClass("invalid");
        }
    });
    $('.contact_email').focusout(function(){
      if($('.contact_email').hasClass("invalid")){
        $('.contact_email').after('<br><span class="error">This field must be valid</span>');
      }
      else{
        $(".error").remove();
      }
    });
    $('.contact_submit').click(function() {
        if ($('.contact_submit').is(':disabled')) {
            $('.contact_submit').removeAttr('disabled');
        } else {
            $('.contact_submit').attr('disabled', 'disabled');
        }
    });

// SURIYA
setInterval(function() { 
    setTimeout(function(){ 
var current_data_attr = $('.testimonial-inner-wrap').attr("data-slide");
var totalCounts = $('.testimonial-section .item').length;

if(current_data_attr > totalCounts ){
$('.testimonial-inner-wrap').attr("data-slide",1);
$('.testimonial-inner-wrap').css('transform', 'translateX(0px)');
}

}, 100);
$('.testimonial-next').click();
}, 3000);

$(".video-popup").click(function(){
$('.modal').css("display","block");
$('input[name="fruits"]:checked').each(function() {
$('.changable').append('<p>'+this.value+'</p>');

});
});

$(".close").click(function(){
$('.modal').css("display","none");
});
var testimonial_width = $('.testimonial-wrapper-inner').width();
console.log(testimonial_width);
//       var whole_width = $('.testimonial-inner-wrap').width();
// $('.testimonial-inner-wrap').css('width' , whole_width+'px');
$('.testimonial-section .item').css('width' , testimonial_width+'px');
$(".testimonial-next").click(function(){
var itemWidth = $('.testimonial-section .item').outerWidth(true);
var totalCounts = $('.testimonial-section .item').length;
var perpage = 1;
var slide_no = $('.testimonial-inner-wrap').attr("data-slide");
translateXval = 1 * slide_no  * itemWidth;
$('.testimonial-prev').removeClass('button-unactive');
$('.testimonial-inner-wrap').attr("data-slide",parseInt(slide_no)+1);
$('.testimonial-inner-wrap').css('transform', 'translateX(' + -translateXval + 'px)');
setTimeout(function(){ 
var current_data_attr = $('.testimonial-inner-wrap').attr("data-slide");
if(current_data_attr == 1 ){
$('.testimonial-prev').addClass('button-unactive');
}
else{
$('.testimonial-prev').removeClass('button-unactive')
}
if(current_data_attr == totalCounts ){
$('.testimonial-next').addClass('button-unactive');
}
else{
$('.testimonial-next').removeClass('button-unactive')
} 
}, 100);
});
$(".testimonial-prev").click(function(){
var itemWidth = $('.testimonial-section .item').outerWidth(true);
var totalCounts = $('.testimonial-section .item').length;
var slide_no = $('.testimonial-inner-wrap').attr("data-slide");
$('.testimonial-inner-wrap').attr("data-slide",parseInt(slide_no)-1);
var slide_no = $('.testimonial-inner-wrap').attr("data-slide");
var perpage = 1;
translateXval -= 1 * itemWidth;
$('.testimonial-inner-wrap').css('transform', 'translateX(' + -translateXval + 'px)');
setTimeout(function(){ 
var current_data_attr = $('.testimonial-inner-wrap').attr("data-slide");
if(current_data_attr == 1 ){
$('.testimonial-prev').addClass('button-unactive');
}
else{
$('.testimonial-prev').removeClass('button-unactive')
}
if(current_data_attr == totalCounts ){
$('.testimonial-next').addClass('button-unactive');
}
else{
$('.testimonial-next').removeClass('button-unactive')
} 
}, 100);
});
// SURIYA==============================================================END=================



    });
    function initMap() {
        const ameex = { lat: 12.965681615693713, lng: 80.24664962946511};
        const map = new google.maps.Map(document.getElementById("map"), {
          zoom: 19,
          center: ameex,
        });
        const marker = new google.maps.Marker({
            position: ameex,
            map: map,
          });
    }






// sHUBHAM Scripts for header, carousal and footer


function myFunction() {
  var x = document.getElementById("myTopnav");
  if (x.className === "topnav") {
    x.className += " responsive";
  } else {
    x.className = "topnav";
  }
}
    
